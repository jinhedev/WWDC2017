/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
The main application JavaScript file.
*/

// Registry of attribute name used to define the URL to template (e.g. documentURL or GridDocumentURL)
// to controller type (e.g. DocumentController or GridDocumentController)
const attributeToController = {};
const attributeKeys = [];
var baseURL;

/**
 * The onLaunch callback is invoked after the application JavaScript has been
 * parsed into a JavaScript context. The handler is passed an object that contains
 * options passed in for launch. These options are defined in the swift or
 * objective-c client code. Options can be used to communicate data as well as 
 * state information to your JavaScript code.
 */
App.onLaunch = function(options) {
    // Determine the base URL for remote server fetches from launch options, which will be used to resolve the URLs
    // in XML files for this app.
    baseURL = options.baseURL;

    // Show a loading spinner while additional JavaScript files are being evaluated
    let loadingDocument = createLoadingDocument();
    navigationDocument.pushDocument(loadingDocument);

    console.log("Loading main script: " + options.mainScript);

    // Load code from utils directory and main application script
    let scriptURLs = [
        "Utilities/DocumentLoader.js",
        "Utilities/DocumentController.js",
        "Utilities/DataLoader.js",
        options.mainScript
    ].map(
        moduleName => baseURL + moduleName
    );

    evaluateScripts(scriptURLs, function(scriptsAreLoaded) {
        if (scriptsAreLoaded) {
            console.log("Scripts have been successfully evaluated.");
        } else {
            // Handle error cases in your code. You should present a readable and user friendly
            // error message to the user in an alert dialog.
            let alertDocument = createEvalErrorAlertDocument();
            navigationDocument.replaceDocument(alertDocument, loadingDocument);
            throw new EvalError("application.js: unable to evaluate scripts.");
        }
    });
};

/**
 * Convenience function to create a TVML loading document with a specified title.
 */
function createLoadingDocument(title) {
    // If no title has been specified, fall back to "Loading...".
    title = title || "Loading...";

    const template = `<?xml version="1.0" encoding="UTF-8" ?>
        <document>
            <loadingTemplate>
                <activityIndicator>
                    <title>${title}</title>
                </activityIndicator>
            </loadingTemplate>
        </document>
    `;
    return new DOMParser().parseFromString(template, "application/xml");
}


/**
 * Convenience function to create a TVML alert document with a title and description.
 */
function createAlertDocument(title, description) {
    const template = `<?xml version="1.0" encoding="UTF-8" ?>
        <document>
            <alertTemplate>
                <title>${title}</title>
                <description>${description}</description>
            </alertTemplate>
        </document>
    `;
    return new DOMParser().parseFromString(template, "application/xml");
}


/**
 * Convenience function to create a TVML alert for failed evaluateScripts.
 */
function createEvalErrorAlertDocument() {
    const title = "Evaluate Scripts Error";
    const description = [
        "There was an error attempting to evaluate the external JavaScript files.",
        "Please check your network connection and try again later."
    ].join("\n\n");
    return createAlertDocument(title, description);
}


/**
 * Convenience function to create a TVML alert for a failed XMLHttpRequest.
 */
function createLoadErrorAlertDocument(url, xhr) {
    const title = (xhr.status) ? `Fetch Error ${xhr.status}` : "Fetch Error";
    const description = `Could not load document:\n${url}\n(${xhr.statusText})`;
    return createAlertDocument(title, description);
}

function registerAttributeName(type, func) {
    attributeToController[type] = func;
    attributeKeys.push(type);
}

function resolveControllerFromElement(elem) {
    for (let key of attributeKeys) {
        if (elem.hasAttribute(key)) {
            return {
                type: attributeToController[key],
                documentURL: elem.getAttribute(key)
            };
        }
    }
}
