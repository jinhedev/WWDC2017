/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
A collection of functions used to demonstrate data binding and prototypes in TVMLKit.
*/

//A DocumentController subclass that handles pagination.
class GridDocumentController extends DocumentController {

    setupDocument(document) {
        super.setupDocument(document)

        //attach a needs more listener to the stackTemplate
        let stackTemplate = document.getElementsByTagName("stackTemplate").item(0)
        if (!stackTemplate) { return }

        //there should be a grid in the stack template
        let grid = stackTemplate.getElementsByTagName("grid").item(0)
        if (!grid) { return }

        //set the initial page to 1
        grid.page = 1

        //using the data url from the grids's first section (there should only be one section per grid)
        let sections = grid.getElementsByTagName("section")
        if (!sections || sections.length == 0) { return }

        let section = sections.item(0)
        let pageUrl = section.getAttribute("dataURL")

        stackTemplate.addEventListener("needsmore", (event) => {
            //replace this code with your logic for getting new pages
            grid.page = grid.page + 1
            if (grid.page > 10) { return } //this is a hardcoded exit criterion

            let nextPageUrl = pageUrl.replace("\.json", "_" + grid.page + ".json")
            this.fetchNextPageAtURL(nextPageUrl, section);
        })
    }
}

//A DocumentController subclass that handles pagination for multiple shelfs
class ShelfDocumentController extends DocumentController {

    setupDocument(document) {
        super.setupDocument(document)

        let shelfs = document.getElementsByTagName("shelf")
        if (!shelfs || shelfs.lenth == 0) { return }

        //enumerate all shelfs in the template
        for (let idx = 0; idx < shelfs.length; ++idx) {
            let shelf = shelfs.item(idx)
            shelf.page = 1

            //using the data url from the shelf's first section (there should only be one section per shelf)
            let sections = shelf.getElementsByTagName("section")
            if (!sections || sections.length == 0) { continue }

            let section = sections.item(0)
            let pageUrl = section.getAttribute("dataURL")

            //add the listener to the shelf
            shelf.addEventListener("needsmore", (event) => {
                //replace this code with your logic for getting new pages
                shelf.page = shelf.page + 1
                if (shelf.page > 10) { return }
                let nextPageUrl = pageUrl.replace("\.json", "_" + shelf.page + ".json")
                this.fetchNextPageAtURL(nextPageUrl, section);
            })
        }
    }
}

registerAttributeName("GridDocumentURL", GridDocumentController)
registerAttributeName("ShelfDocumentURL", ShelfDocumentController)

class CatalogDocumentController extends DocumentController {

    setupDocument(document) {
        super.setupDocument(document)

        let element1 = document.getElementById("Row1");
        let element2 = document.getElementById("Row2");

        [element1, element2].forEach((element) => {
            element.addEventListener("highlight", (event) => {
                //find the first section below the selected item
                let sections = event.target.getElementsByTagName("section")
                if (!sections || sections.length == 0) { return }

                //the attribute dataURL will automatically resolve the binding on load - see DataLoader.js' prepareDocument function.
                let section = sections.item(0)
                let url = section.getAttribute("lazyDataURL")
                if (!url) { return }

                //if we already have one data item, then we
                //exit here so we don't fetch data again. Your app might need different checks.
                if (section.dataItem) { return }
                section.dataItem = new DataItem()

                //show an activity indicator while the data is fetching.
                let relatedContent = element.getElementsByTagName("relatedContent").item(0)
                let activityIndicator = element.ownerDocument.createElement('activityIndicator')
                relatedContent.insertBefore(activityIndicator, relatedContent.children.item(0))

                this._dataLoader._fetchJSONData(this._documentLoader.prepareURL(url), (dataObj) => {
                  section.dataItem.setPropertyPath("items", this._dataLoader._dataItemFromJSONItems(dataObj.items))
                  relatedContent.removeChild(activityIndicator)
                })
            })
        })
    }
}

registerAttributeName("CatalogDocumentURL", CatalogDocumentController)

// Create a DocumentLoader to handle fetching templates
let documentLoader = new DocumentLoader(baseURL + "DataBinding/")
let documentURL = documentLoader.prepareURL("/Index.xml")
let loadingDocument = getActiveDocument()
new DocumentController({ documentLoader, documentURL, loadingDocument })
