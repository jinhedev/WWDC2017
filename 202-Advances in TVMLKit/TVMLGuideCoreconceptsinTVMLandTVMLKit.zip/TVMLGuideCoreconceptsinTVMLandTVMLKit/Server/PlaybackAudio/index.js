/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
The main script for the PlaybackAudio example.
*/

// Get a reference to the loading template that was pushed in application.js
const loadingDocument = getActiveDocument();

// Create a DocumentLoader to handle fetching templates
const documentLoader = new DocumentLoader(baseURL + "PlaybackAudio/");

// Store the documents that will be fetched concurrently.
let menuBarDocument, stackDocument;

// Fetch the menu bar template that will be the root document
documentLoader.fetch({
    url: "/Index.xml",
    concurrent: true,
    success: (document) => {
        menuBarDocument = document;
        // Show the documents if everything has finished loading.
        if (menuBarDocument && stackDocument) {
            showLoadedDocuments();
        }
    },
    error: showLoadingError
});
// Also fetch the stack template that will be the track list of lockups
documentLoader.fetch({
    url: "/Stack.xml",
    concurrent: true,
    success: (document) => {
        stackDocument = document;
        // Show the documents if everything has finished loading.
        if (menuBarDocument && stackDocument) {
            showLoadedDocuments();
        }
    },
    error: showLoadingError
});

/*
 * A function that is used to prepare the documents for display.
 * Replaces the loading template with a menu bar template.
 */
function showLoadedDocuments() {
    const menuBarElem = menuBarDocument.getElementsByTagName("menuBar").item(0);
    const menuItemElem = menuBarDocument.getElementsByTagName("menuItem").item(0);
    // Set the stack document on the menu bar item
    const menuBarFeature = menuBarElem.getFeature("MenuBarDocument");
    menuBarFeature.setDocument(stackDocument, menuItemElem);
    // Set up event listeners to playback a focused lockup.
    stackDocument.addEventListener("play", playSelectedLockup);
    stackDocument.addEventListener("select", playSelectedLockup);
    // Display the menu bar document with the stack document inside of it
    navigationDocument.replaceDocument(menuBarDocument, loadingDocument);
}

function showLoadingError(xhr) {
    // Use a utility function to create an alert document from the XHR error.
    const alertDocument = createLoadErrorAlertDocument(xhr);
    // Show the alert document instead of the loading template.
    navigationDocument.replaceDocument(alertDocument, loadingDocument);
}


/*
 * A function that is registered as an event listener to handle
 * 'select' and 'play' events on lockups in the stack document.
 * Sets up and starts a player for the selected audio track.
 */
function playSelectedLockup(event) {
    const targetElem = event.target;
    // Convert the URL on the lockup from relative to absolute with the DocumentLoader
    const audioURL = documentLoader.prepareURL(targetElem.getAttribute("audioURL"));
    if (audioURL) {
        // Prepare an Audio MediaItem with metadata from the lockup...
        const mediaItem = new MediaItem("audio", audioURL);
        // Assign the artwork metadata
        const imgElem = targetElem.getElementsByTagName("img").item(0);
        if (imgElem && imgElem.hasAttribute("src")) {
            mediaItem.artworkImageURL = imgElem.getAttribute("src");
        }
        // Assign the title metadata
        const titleElem = targetElem.getElementsByTagName("title").item(0);
        if (titleElem) {
            mediaItem.title = titleElem.textContent;
        }
        // Create a Player and assign the MediaItem to its Playlist
        const player = new Player();
        player.playlist = new Playlist();
        player.playlist.push(mediaItem);
        // Present the player and start playback
        player.play();
    }
}
