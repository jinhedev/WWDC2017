/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
A collection of functions used to present videos with different properties and configurations.
*/

// Create a DocumentLoader to handle fetching templates
const documentLoader = new DocumentLoader(baseURL + "ExtendingTemplates/");

// Fetch the Index template that will be the root document
documentLoader.fetch({
    url: "/Index.xml",
    success: (document) => {
        // Register handler to show documents on selection
        document.addEventListener('select', handleSelectEvent);
        // Show the index document instead of the loading template.
        const loadingDocument = getActiveDocument();
        navigationDocument.replaceDocument(document, loadingDocument);
    },
    error: (xhr) => {
        // Use a utility function to create an alert document from the XHR error.
        const alertDocument = createLoadErrorAlertDocument(xhr);
        // Show the alert document instead of the loading template.
        navigationDocument.replaceDocument(alertDocument, loadingDocument);
    }
});

/**
 * A function that is assigned to handle select events for elements to push new
 * documents.
 */
function handleSelectEvent(event) {
    // Check if the selected element has a documentURL attribute set.
    const selectedElement = event.target;
    const targetPath = selectedElement.getAttribute("documentURL");

    if (targetPath) {
        // Fetch the document for display
        documentLoader.fetch({
            url: targetPath,
            success: (document) => {
                // Register selection handler to show child documents
                document.addEventListener('select', handleSelectEvent);
                // Present the document for display
                navigationDocument.pushDocument(document);
            }
        });
    }
}

/*
 * A function to handle highlight event on the featured shelf. The implementation
 * changes the background image of the feature shelf.
 */
function featuredShelfOnHighlight(event) {
    // event.target refers to the element on which the event occurred.
    const lockupElement = event.target;
    const bgImgSrc = "resource://" + lockupElement.getAttribute('bgImg');

    // event.currentTarget refers to the element where the event handler was attached.
    const shelfElement = event.currentTarget;
    const bgElement = shelfElement.getElementsByTagName('background').item(0);
    const bgImgElement = bgElement.getElementsByTagName('img').item(0);

    // Update the section background image URL if necessary.
    if (bgImgElement.getAttribute('src') !== bgImgSrc) {
        bgImgElement.setAttribute('src', bgImgSrc);
    }
}
