/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
A collection of functions used to present videos with different properties and configurations.
*/

// Get a reference to the loading template that was pushed in application.js
const loadingDocument = getActiveDocument();

// Create a DocumentLoader to handle fetching templates
const documentLoader = new DocumentLoader(baseURL + "PlaybackVideo/");

// Store the video metadata loaded from JSON over XHR
let allVideos;

// Video that contains timed metadata
const playerEventsVideo = null; // new MediaItem("video", "HLS stream with timedMetadata");)

// Fetch the list template from the server to show as the root document.
documentLoader.fetch({
    url: "/Index.xml",
    success: (document) => {
        // Show the loaded document instead of the loading template.
        const videosXHR = new XMLHttpRequest();
        const videosURL = documentLoader.prepareURL("/videos.json");
        videosXHR.open("GET", videosURL);
        videosXHR.responseType = "json";
        videosXHR.onload = () => {
            allVideos = videosXHR.response;

            // Resolve URLs relative to baseURL
            allVideos.forEach((video) => {
                video.url = documentLoader.prepareURL(video.url);
                video.artworkImageURL = documentLoader.prepareURL(video.artworkImageURL);

                if (video.highlightGroups) {
                    video.highlightGroups.forEach((highlightGroup) => {
                        highlightGroup.highlights.forEach((highlight) => {
                            highlight.imageURL = documentLoader.prepareURL(highlight.imageURL);
                        });
                    });
                }

            });
            navigationDocument.replaceDocument(document, loadingDocument);
        }
        videosXHR.onerror = () => {
            const alertDocument = createLoadErrorAlertDocument(videosURL, videosXHR);
            navigationDocument.presentModal(alertDocument);
        }
        videosXHR.send();
    },
    error: (xhr) => {
        // Use a utility function to create an alert document from the XHR error.
        const alertDocument = createLoadErrorAlertDocument(xhr);
        // Show the alert document instead of the loading template.
        navigationDocument.replaceDocument(alertDocument, loadingDocument);
    }
});

/** 
 * Convinence method to load a document
 */
function loadDocument(url) {
    documentLoader.fetch({ url: url });
}

/**
 * Presents a video with meta data such as title etc.
 */
function presentSimpleVideo() {
    // Use the information for the first video.
    const videoInfo = allVideos[0];

    // Create a MediaItem for the video.
    const mediaItem = createMediaItem(videoInfo);

    // Push the the video's media item onto a new playlist.
    const playlist = new Playlist();
    playlist.push(mediaItem);

    // Create a Player and have it play the playlist.
    const player = new Player();
    player.playlist = playlist;
    player.play();
}


/**
 * Presents a video and adds a simple text overlay.
 */
function presentVideoWithOverlay() {
    // Use the information for the first video.
    const videoInfo = allVideos[0];

    // Create a MediaItem for the video.
    const mediaItem = createMediaItem(videoInfo);

    // Push the the video's media item onto a new playlist.
    const playlist = new Playlist();
    playlist.push(mediaItem);

    // Create a simple document using the divTemplate to use as an overlay on the video.
    const overlayText = "Text in an overlay document";

    // Create a Player and have it play the playlist.
    const player = new Player();
    player.playlist = playlist;

    createOverlayDocument(overlayText, (overlayDocument) => {
        player.overlayDocument = overlayDocument;
        player.play();
    });
}

/**
 * Presents a video and adds an interactive overlay
 */
function presentVideoWithInteractiveOverlay() {
    // Use the information for the first video.
    const videoInfo = allVideos[0];

    // Create a MediaItem for the video.
    const mediaItem = createMediaItem(videoInfo);

    // Push the the video's media item onto a new playlist.
    const playlist = new Playlist();
    playlist.push(mediaItem);

    // Create a Player and have it play the playlist.
    const player = new Player();
    player.playlist = playlist;
    player.interactiveOverlayDismissable = true;

    createInteractiveOverlayDocument(allVideos, (interactiveOverlayDocument) => {
        interactiveOverlayDocument.player = player
        player.interactiveOverlayDocument = interactiveOverlayDocument;
        player.play();
    });
}

/**
 * Presents a number of videos in a playlist. When a video ends, the next video
 * in the playlist automatically starts playing.
 */
function presentMultipleVideoPlaylist() {
    // Create a playlist to add video media items to.
    const playlist = new Playlist();

    /*
     * Loop through the videos, creating a media item for each and adding it to
     * the playlist.
     */
    for (let videoInfo of allVideos) {
        const mediaItem = createMediaItem(videoInfo);
        playlist.push(mediaItem);
    }

    // Create a Player and have it play the playlist.
    const player = new Player();
    player.playlist = playlist;
    player.play();
}


/**
 * Presents a video with unskippable advertisements.
 */
function presentVideoWithAds() {
    // Use the information for the first video.
    const videoInfo = allVideos[0];

    // Create a MediaItem for the video.
    const mediaItem = createMediaItem(videoInfo, true);

    // Push the the video's media item onto a new playlist.
    const playlist = new Playlist();
    playlist.push(mediaItem);

    // Create a Player and set its playlist.
    const player = new Player();
    player.playlist = playlist;

    /*
     * Add an event listener for the requestSeekToTime event. This will be used
     * to prevent the user from skipping advertisements.
     */
    player.addEventListener("requestSeekToTime", (event) => {
		// Logic for unskippable ads
		// 1. If we are within an interstitial, only allow skipping within the interstitial
		// 2. If we are not, we should skip to the one that is closest to us
		
        const now = event.currentTime;
		const requestedTime = event.requestedTime
		var closestInterstitial = null

        // Default to allowing the user to seek from the current playback position.
        let allowSeek = true;

        // Check if the current playback time is within any of the ad timings for the video.
        videoInfo.interstitials.forEach( interstitial => {
			// Figure out if we are within an interstitial and are seeking out of it
			let withinInterstitial = (now >= interstitial.starttime && now <= interstitial.endtime)
			let seekingOutOfInterstitial = (requestedTime > interstitial.endtime || requestedTime < interstitial.starttime)

			// Find all interstitials that are forwards of us but before requested time
			if (!withinInterstitial && now < requestedTime && interstitial.starttime > now && interstitial.starttime < requestedTime) {
				// Find the one closest to the current time
				if (closestInterstitial == null) {
					closestInterstitial = interstitial
				} else if (interstitial.starttime < closestInterstitial.starttime) {
					closestInterstitial = interstitial
				}
			}			
			
            if (withinInterstitial && seekingOutOfInterstitial) {
                /*
                 * The current playback time is within an interaval marked as an
                 * advertisement. Don't allow the user to seek from the current
                 * playback position.
                 */
                allowSeek = false;
            }
        });
		
		if (allowSeek && closestInterstitial != null) {
			// Being allowed to seek means we aren't within an interstitial
			return closestInterstitial.starttime;
		} else {
			return allowSeek ? requestedTime : now;
		}
    });
	
	player.addEventListener("shouldHandleStateChange", (event) => {
        const now = event.elapsedTime;
		var allowSeek = true;
        videoInfo.interstitials.forEach( interstitial => {
			let withinInterstitial = (now >= interstitial.starttime && now <= interstitial.endtime)
			if (withinInterstitial && allowSeek && event.state == "paused")
			{
				allowSeek = false;
			}
        });
		return allowSeek;
	});

    // Play the playlist.
    player.play();
}


/**
 * Presents a video with a highlight group to allow the user to easily jump to
 * highlights within the video.
 */
function presentVideoWithHighlightGroup() {
    // Use the information for the first video.
    const videoInfo = allVideos[0];

    // Create a MediaItem for the video.
    const mediaItem = createMediaItem(videoInfo);

    // Specify highlight groups for the media item.
    mediaItem.highlightGroups = videoInfo.highlightGroups;

    // Push the the video's media item onto a new playlist.
    const playlist = new Playlist();
    playlist.push(mediaItem);

    // Create a Player and have it play the playlist.
    const player = new Player();
    player.playlist = playlist;
    player.play();
}

/**
 * Presents a video with showcasing how player events work
 */
function presentVideoWithPlayerEvents() {
    if (!playerEventsVideo) {
        const alertDocument = createAlertDocument("Action Required", "Please modify the index.js to include an actual MediaItem in the \"playerEventsVideo\" constant that points to a HLS stream that has timedMetadata.")
        navigationDocument.presentModal(alertDocument);
        return;
    }

    // Push the the video's media item onto a new playlist.
    const playlist = new Playlist();
    playlist.push(playerEventsVideo);

    // Create a Player and have it play the playlist.
    const player = new Player();
    player.playlist = playlist;
    player.play();
	
    documentLoader.fetch({
        url: "/PlayerEventsOverlay.xml",
        success: (document) => {
			player.overlayDocument = document;
			
			player.addEventListener("stateDidChange", function(event) {
				let element = document.getElementById("state")
				element.textContent = "State changed from " + event.oldState + " to " + event.state;
			});
			player.addEventListener("currentMediaItemDurationChanged", function(info) {
				let element = document.getElementById("mediaItemDuration")
				element.textContent = "Current MediaItem duration changed to " + info.duration;
			});
			player.addEventListener("timeDidChange", function(info) {
				let element = document.getElementById("time")
				element.textContent = "Time is now " + info.time;
			}, {"interval": 1});
			player.addEventListener("timedMetadata", function(event) {
				let element = document.getElementById("timedMetadata")
				element.textContent = "timedMedata: " + event.metadata.stringValue;
				console.log(JSON.stringify(event))
			}, null);
			player.addEventListener("transportBarVisibilityDidChange", function(info) {
				let element = document.getElementById("transportBar")
				element.textContent = "TransportBar is " + (info.hidden ? "hidden" : "visible");
			});
			player.addEventListener("playbackDidStall", function(info) {
				let element = document.getElementById("stall")
				element.textContent = "Playback stalled at " + info.elapsedTime;
			});
			player.addEventListener("playbackError", function(info) {
				let element = document.getElementById("error")
				element.textContent = "Playback error: " + info.reaseon + ", shouldStopDueToerror: " + info.shouldStopDueToError;
			});
        }
    });
}

/**
 * Convenience function to create a MediaItem object for a set of video information.
 */
function createMediaItem(mediaInfo, ads) {
    const mediaItem = new MediaItem("video");
    for (let key in mediaInfo) {
		let addKey = true;
		if (key == "interstitials") {
			addKey = ads
		}
		
		if (addKey) {
	        mediaItem[key] = mediaInfo[key];						
		}
    }
    return mediaItem;
}

/**
 * Convenience function to create a stack TVML document that can be used as an
 * interactive overlay over a video.
 */
function createInteractiveOverlayDocument(videos, callback) {
    documentLoader.fetch({
        url: "/InteractiveOverlay.xml",
        success: (document) => {
            const parser = document.implementation.createLSParser(0, null);
            const input = document.implementation.createLSInput();

            videos.forEach((video, index) => {
                input.stringData += `
                    <lockup onselect="playVideoFromInteractiveOverlay(event, ${index})">
                        <img src="${video.artworkImageURL}" aspectFill="true" width="250" height="250" />
                        <title>${video.subtitle}</title>
                    </lockup>
                `;
            });

            const insertionPoint = document.getElementsByTagName('section').item(0);
            parser.parseWithContext(input, insertionPoint, 1);

            callback(document);
        },
        error: (xhr) => {
            callback(null);
        }
    });
}

/**
 * Convenience function to play a video based on its index
 * and target. Used by onselect in lockups
 */

function playVideoFromInteractiveOverlay(event, videoIndex) {
    const selectedElem = event.target;
    const document = selectedElem.ownerDocument;
    const player = document.player;
    const mediaItem = createMediaItem(allVideos[videoIndex]);
    player.playlist.push(mediaItem);
    player.next();
}

/**
 * Convenience function to create a div TVML document that can be used as an
 * overlay over a video.
 */
function createOverlayDocument(text, callback) {
    documentLoader.fetch({
        url: "/Overlay.xml",
        success: (document) => {
            const insertionPoint = document.getElementsByTagName('text').item(0);
            insertionPoint.textContent = text;
            callback(document);
        },
        error: (xhr) => {
            callback(null);
        }
    });
}

function setupMediaContent(target, src, artworkURL) {
    const mediaContentList = target.getElementsByTagName('mediaContent');
    for (let i = 0; i < mediaContentList.length; i++) {
        const mediaContent = mediaContentList.item(i);
        const image = mediaContent.getElementsByTagName('img').item(0);
        const mediaSource = src ? src : mediaContent.getAttribute('mediaContent');
        const imageSrc = artworkURL ? artworkURL : mediaContent.getAttribute('artworkURL');

        if (image && imageSrc) {
            image.setAttribute("src", documentLoader.prepareURL(imageSrc));
        }

        const player = mediaContent.getFeature('Player');

        if (player && mediaSource) {
            const mediaItem = new MediaItem('video', documentLoader.prepareURL(mediaSource));
            mediaItem.artworkImageURL = documentLoader.prepareURL(mediaContent.getAttribute('artworkURL'));

            player.playlist = new Playlist();
            player.playlist.push(mediaItem);
        }
    }
}

function presentVideo(target) {
    const mediaContent = target.getElementsByTagName('mediaContent').item(0);
    const player = mediaContent.getFeature('Player');
    player.present();
}
