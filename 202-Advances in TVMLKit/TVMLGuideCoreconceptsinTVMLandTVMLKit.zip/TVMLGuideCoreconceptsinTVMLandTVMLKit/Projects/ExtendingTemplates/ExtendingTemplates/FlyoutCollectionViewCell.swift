/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Class to implement the custom cell.
*/

import UIKit

class FlyoutCollectionViewCell: UICollectionViewCell {
	
	// MARK: Public
	
	var images: [UIView]? {
		willSet {
			// Remove old images and then request for relayout.
			if let images = self.images {
				for oldImage in images {
					oldImage.removeFromSuperview()
				}
			}
			if let imageSheens = self.imageSheens {
				for oldImageSheen in imageSheens {
					oldImageSheen.removeFromSuperview()
				}
			}
			self.setNeedsLayout()
		}
	}
	
	var focusMargin: UIEdgeInsets?
	
	// MARK: Overrides
	
	override init(frame: CGRect) {
		super.init(frame: frame);
		
		baseView = UIView(frame: bounds)
		baseView?.backgroundColor = UIColor(white: 0.6, alpha: 0.6)
		baseView?.alpha = 0.0
		contentView.addSubview(baseView!)
		
		shadowView = UIView(frame: bounds)
		shadowView?.layer.shadowColor = UIColor.black.cgColor
		shadowView?.layer.shadowRadius = 40.0
		shadowView?.layer.shadowOpacity = 0.7
		shadowView?.alpha = 0.0
		contentView.addSubview(shadowView!)
	}
	
	required init?(coder aDecoder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
	
	override func layoutSubviews() {
		super.layoutSubviews()
		
		let contentBounds = self.contentBounds
		let contentDimension = contentBounds.size.width
		let imageBounds = CGSize(width: contentDimension, height: contentDimension)
		
		baseView!.frame = contentBounds
		shadowView!.frame = contentBounds
		
		if shadowView!.layer.shadowPath == nil {
			if let focusMargin = self.focusMargin {
				shadowView?.layer.shadowPath = CGPath(rect: CGRect(x: contentBounds.origin.x - focusMargin.left,
				                                                   y: contentBounds.origin.y - focusMargin.top,
				                                                   width: contentBounds.size.width + focusMargin.left + focusMargin.right,
				                                                   height: contentBounds.size.height + focusMargin.top + focusMargin.bottom),
				                                      transform: nil)
			}
			else {
				shadowView!.layer.shadowPath = CGPath(rect: contentBounds, transform: nil)
			}
		}
		
		if let images = self.images {
			self.imageSheens = [UIView]()
			
			// Add all the images first.
			for image in images {
				if image.superview != self {
					contentView.addSubview(image)
					
					// Create a sheen for it.
					let sheenView = UIView()
					sheenView.backgroundColor = UIColor(white: 1.0, alpha: 0.6)
					sheenView.alpha = 1.0
					contentView.addSubview(sheenView)
					imageSheens!.append(sheenView)
				}
			}
			
			// Layout these images.
			var imagePositionIndex = 0
			for image in images {
				let imageSheen = self.imageSheens![imagePositionIndex]
				
				// Set the image bounds.
				let imageSize = image.sizeThatFits(imageBounds)
				image.bounds = CGRect(origin: CGPoint(), size: imageSize)
				
				// Set the image center based on its position.
				var imageCenter = CGPoint()
				switch imagePositionIndex {
				case 0:
					// Center position
					imageCenter = CGPoint(x: contentBounds.origin.x + contentDimension * 0.5,
					                      y: contentBounds.origin.y + contentDimension * 0.5)
					break
					
				case 1:
					// Top-left position
					imageCenter = CGPoint(x: contentBounds.origin.x + imageSize.width * 0.5,
					                      y: contentBounds.origin.y + imageSize.height * 0.5)
					break
					
				case 2:
					// Right position
					imageCenter = CGPoint(x: contentBounds.origin.x + (contentDimension - imageSize.width * 0.5),
					                      y: contentBounds.origin.y + contentDimension * 0.5)
					break
					
				case 3:
					// Bottom position
					imageCenter = CGPoint(x: contentBounds.origin.x + contentDimension * 0.5,
					                      y: contentBounds.origin.y + (contentDimension - imageSize.height * 0.5))
					break
					
				default:
					break
				}
				image.center = imageCenter
				
				// Setup the sheen to mimic the image
				imageSheen.bounds = image.bounds
				imageSheen.center = image.center
				
				// Increment the position
				imagePositionIndex += 1
			}
			
			// Configure the flyout for current state.
			self.configureFlyout();
		}
	}
	
    override var canBecomeFocused: Bool {
		return true
	}
	
	override func didUpdateFocus(in context: UIFocusUpdateContext, with coordinator: UIFocusAnimationCoordinator) {
		coordinator.addCoordinatedAnimations({
			self.configureFlyout();
		}, completion: nil)
	}
	
	// MARK: Private
	
	private var baseView: UIView?
	private var shadowView: UIView?
	private var imageSheens: [UIView]?
	
	private var contentBounds: CGRect {
		get {
			let minDimension = min(bounds.size.width, bounds.size.height)
			let boundsOffset = CGPoint(x: floor((bounds.size.width - minDimension) * 0.5),
			                           y: floor((bounds.size.width - minDimension) * 0.5))
			return CGRect(origin: boundsOffset, size: CGSize(width: minDimension, height: minDimension))
		}
	}
	
	private func configureFlyout() {
		if let images = self.images {
			// Translate the image to flyout
			var imagePositionIndex = 0
			for image in images {
				let imageSheen = imageSheens![imagePositionIndex]
				
				// Use transform to retain the values set in layoutSubviews
				var transform = CGAffineTransform.identity
				if focusMargin != nil && isFocused {
					let contentBounds = self.contentBounds
					let imageBounds = image.bounds
					let imageOrigin = CGPoint(x: image.center.x - imageBounds.size.width * 0.5,
											  y: image.center.y - imageBounds.size.height * 0.5)
					let imageFrame = CGRect(origin: imageOrigin, size: imageBounds.size)
					
					switch imagePositionIndex {
					case 0:
						// Center moves to top-right.
						transform = CGAffineTransform(translationX: contentBounds.maxX - imageFrame.maxX + focusMargin!.right,
													  y: -(imageFrame.minY - contentBounds.minY) - focusMargin!.top)
						break
						
					case 1:
						// Top-left stays at top-left
						transform = CGAffineTransform(translationX: -focusMargin!.left,
													  y: -focusMargin!.top)
						break
						
					case 2:
						// Right moves to bottom-right
						transform = CGAffineTransform(translationX: focusMargin!.right,
													  y: contentBounds.maxY - imageFrame.maxY + focusMargin!.bottom)
						break;
						
					case 3:
						// Bottom moves to bottom-left
						transform = CGAffineTransform(translationX: -(imageFrame.minX - contentBounds.minX) - focusMargin!.left,
													  y: focusMargin!.bottom)
						break;
						
					default:
						break
					}
				}
				image.transform = transform
				imageSheen.transform = transform;
				
				imagePositionIndex += 1
			}
			
			// Crossfade the background views.
			baseView?.alpha = isFocused ? 0.1 : 0.0
			shadowView?.alpha = isFocused ? 1.0 : 0.0
			
			// Fade out the image sheens when focused.
			for imageSheen in imageSheens! {
				imageSheen.alpha = self.isFocused ? 0.0 : 1.0
			}
		}
	}
}
