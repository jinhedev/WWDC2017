/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Custom collection controller for stack template.
*/

import UIKit
import TVMLKit

class FeaturedShelfView: UIView {
    var padding: UIEdgeInsets?
    
    var shelfView: UIView? {
        willSet {
            if self.shelfView != shelfView {
                self.shelfView?.removeFromSuperview()
            }
        }
        didSet {
            if let shelfView = self.shelfView {
                if shelfView.superview != self {
                    self.addSubview(shelfView)
                }
            }
        }
    }
    
    private var _backgroundImageView: UIView?
    var backgroundImageView: UIView? {
        get {
            return _backgroundImageView
        }
        set {
            let oldImageView = _backgroundImageView
            self._backgroundImageView = newValue
            
            if window != nil {
                // Add the background view first.
                if let imageView = newValue {
                    imageView.frame = bounds
                    self.insertSubview(imageView, at: 0)
                }
                
                // Crossfade the background images.
                newValue?.alpha = 0.0
                UIView.animate(
                    withDuration: 0.5,
                    animations: {
                        newValue?.alpha = 1.0
                        oldImageView?.alpha = 0.0
                    },
                    completion: { _ in
                        oldImageView?.removeFromSuperview()
                    }
                )
            }
            else {
                if let imageView = newValue {
                    insertSubview(imageView, at: 0)
                }
                oldImageView?.removeFromSuperview()
            }
        }
    }
    
    override func sizeThatFits(_ size: CGSize) -> CGSize {
        if let shelfView = self.shelfView {
            let shelfSize = shelfView.sizeThatFits(CGSize(width: size.width, height: 0.0))
            let padding = self.padding ?? UIEdgeInsets()

            return CGSize(width: size.width, height: shelfSize.height + padding.top + padding.bottom)
        }
        return CGSize.zero
    }
    
    override func layoutSubviews() {
        let bounds = self.bounds
        let padding = self.padding ?? UIEdgeInsets()
        
        self.backgroundImageView?.frame = bounds
        
        if let shelfView = self.shelfView {
            let shelfSize = shelfView.sizeThatFits(CGSize(width: bounds.size.width, height: 0.0))
            self.shelfView?.frame = CGRect(x: 0.0, y: padding.top, width: bounds.width, height: shelfSize.height)
        }
    }
}

class FeaturedShelfViewController: UIViewController {
    
    // MARK: Public
    
    func update(withElement element: TVViewElement) {
        // Parse the shelf element and the background image element.
        var shelfElement: TVViewElement?
        var backgroundImageElement: TVImageElement?
        if let children = element.children {
            for childElement in children {
                if childElement.name == "shelf" {
                    shelfElement = childElement
                }
                else if childElement.name == "background" {
                    if let children = childElement.children {
                        for childElement in children {
                            if childElement.name == "img" {
                                backgroundImageElement = childElement as? TVImageElement
                            }
                        }
                    }
                }
            }
        }
        self.featuredShelfElement = element
        self.shelfElement = shelfElement
        
        // Create a shelf through TVMLKit.
        if let shelfElement = shelfElement {
            // Make sure to pass in the existing shelf view controller in order to
            // reuse it for updates.
            if self.shelfViewController == nil || shelfElement.updateType != TVElementUpdateType.none {
                self.shelfViewController = TVInterfaceFactory.shared().makeViewController(element: shelfElement, existingViewController: self.shelfViewController)
            }
        }
        
        // Set up the background image.
        var backgroundImageName: String?
        if let backgroundImageURL = backgroundImageElement?.url {
            backgroundImageName = backgroundImageURL.host!
        }
        
        if backgroundImageName != self.backgroundImageName {
            self.backgroundImageName = backgroundImageName
            
            var imageView: UIImageView?
            if let backgroundImageName = backgroundImageName {
                imageView = UIImageView()
                imageView?.contentMode = UIViewContentMode.scaleToFill
                imageView?.image = UIImage(named: backgroundImageName)
            }
            
            self.backgroundImageView = imageView
        }
        
        // Update the view.
        self.featuredShelfView?.padding = self.featuredShelfElement?.style?.padding
        self.featuredShelfView?.backgroundImageView = self.backgroundImageView
        self.featuredShelfView?.shelfView = self.shelfViewController?.view
    }
    
    // MARK: Overrides
    
    override func loadView() {
        self.view = FeaturedShelfView()
        
        // Update the view.
        self.featuredShelfView?.padding = self.featuredShelfElement?.style?.padding
        self.featuredShelfView?.backgroundImageView = self.backgroundImageView
        
        if let shelfViewController = self.shelfViewController {
            self.addChildViewController(shelfViewController)
            self.featuredShelfView?.shelfView = self.shelfViewController?.view
            shelfViewController.didMove(toParentViewController: self)
        }
    }
    
    override var preferredFocusEnvironments: [UIFocusEnvironment] {
        get {
            var environments = [UIFocusEnvironment]();
            if let shelfViewController = self.shelfViewController {
                environments.append(shelfViewController);
            }
            
            return environments;
        }
    }
    
    // MARK: Private
    
    private var backgroundImageName: String?
    private var backgroundImageView: UIImageView?
    private var shelfViewController: UIViewController?
    private var featuredShelfElement: TVViewElement?
    private var shelfElement: TVViewElement?
    
    private var featuredShelfView: FeaturedShelfView? {
        get {
            if self.isViewLoaded {
                return self.view as? FeaturedShelfView
            }
            return nil
        }
    }
}
