/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Interface creator that extends TVMLKit.
*/

import TVMLKit

@objc
class ExtendedInterfaceCreator : NSObject, TVInterfaceCreating {
	
	// Override to provide custom cell classes for TVMLKit collections.
	func collectionViewCellClass(for element: TVViewElement) -> AnyClass? {
		// Map elements to their corresponding cell class
		switch element.name {
		case "flyoutCell":
			return FlyoutCollectionViewCell.self
			
		default:
			break
		}
		return nil
	}
	
	// Override to configure custom views and cells.
	func makeView(element: TVViewElement, existingView: UIView?) -> UIView? {
		// Map elements to their corresponding views
		switch element.name {
		case "flyoutCell":
			// For cells existing view will always refer to the cell that's dequeued
			// for this element.
			let flyoutCell = existingView as? FlyoutCollectionViewCell
			self.configureFlyoutCell(element: element, cell: flyoutCell!)
			return flyoutCell
			
		case "rainbowProgressBar":
			var rainbowProgressBar = existingView as? RainbowProgressBar
			if rainbowProgressBar == nil  {
				rainbowProgressBar = RainbowProgressBar()
			}
			self.configureRainbowProgressBar(element: element, rainbowProgressBar: rainbowProgressBar!)
			return rainbowProgressBar
			
		default:
			break
		}
		return nil
	}
	
	func makeViewController(element: TVViewElement, existingViewController: UIViewController?) -> UIViewController? {
		// Map elements to their corresponding view controllers
		switch element.name {
		case "featuredShelf":
			var featuredShelfViewController = existingViewController as? FeaturedShelfViewController
			if featuredShelfViewController == nil  {
				featuredShelfViewController = FeaturedShelfViewController()
			}
			self.configureFeatureShelf(element: element, featuredShelfViewController: featuredShelfViewController!)
			return featuredShelfViewController
			
		default:
			break
		}
		return nil
	}
	
	/*
	A flyouCell has the following markup spec:
		<flyoutCell>
			<img/>
			<img/>
			<img/>
			<img/>
		</flyoutCell>
	
	Always remember to add the following styles to your custom cell elements:
		width:
			Specify the width of your cell in unfocused state.
		height:
			Specify the height of your cell in unfocused state.
		tv-focus-margin:
			Specify the amount the cell will grow on each side in the focused state.
	*/
	private func configureFlyoutCell(element: TVViewElement, cell: FlyoutCollectionViewCell) {
		// Parse the contained image elements to create images.
		var images = [UIView]()
		if let children = element.children {
			for case let childElement as TVImageElement in children {
                // Use TVMLKit to create images.
                if let image = TVInterfaceFactory.shared().makeView(element: childElement, existingView: nil) {
                    images.append(image)
                }
			}
		}
		
		// Set the images in the cell.
		if let focusMargin = element.style?.focusMargin {
			cell.focusMargin = focusMargin
		}
		else {
			cell.focusMargin = UIEdgeInsets(top: 30.0, left: 30.0, bottom: 30.0, right: 30.0)
		}
		cell.images = images
	}
	
	/*
	A rainbowProgressBar has the following markup spec:
	<rainbowProgressBar value="progress"/>
	
	Make sure to explicitly style custom elements. In this case for instance,
	it's mandatory to set the width and height of the progress bar.
	*/
	private func configureRainbowProgressBar(element: TVViewElement, rainbowProgressBar: RainbowProgressBar) {
		if let valueStr = element.attributes?["value"] {
			if let value = Float(valueStr) {
				rainbowProgressBar.setProgress(value, animated: true)
			}
		}
	}
	
	/*
	A featuredShelf has the following markup spec:
		<featuredShelf>
			<background>
				<img/>
			</background>
			<shelf>...</shelf>
		</featuredShelf>
	
	It reuses background, img and shelf elements, while hosting the shelf view
	controller and view provided by TVMLKit.
	*/
	private func configureFeatureShelf(element: TVViewElement, featuredShelfViewController: FeaturedShelfViewController) {
		featuredShelfViewController.update(withElement: element)
	}
}
