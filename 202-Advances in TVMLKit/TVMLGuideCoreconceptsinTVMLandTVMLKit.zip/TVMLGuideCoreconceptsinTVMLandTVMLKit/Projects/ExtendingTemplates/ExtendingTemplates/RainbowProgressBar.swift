/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View for rainbow progress.
*/

import Foundation
import UIKit
import QuartzCore
import CoreGraphics

class RainbowProgressBar: UIView {
	
	override init(frame: CGRect) {
		super.init(frame: frame)
		clipsToBounds = true
		backgroundColor = UIColor(white: 0.3, alpha: 1.0)
		layer.borderColor = UIColor.black.cgColor
		layer.borderWidth = 1.0
		layer.cornerRadius = 10.0
		
		progressView.layer.borderColor = UIColor.black.cgColor
		progressView.layer.borderWidth = 1.0
		progressView.layer.cornerRadius = 10.0
		progressView.clipsToBounds = true
		
		progressView.addSubview(firstImageView)
		progressView.addSubview(secondImageView)
		addSubview(progressView)
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
	
	var progress: Float {
		get {
			return _progress
		}
		set {
			setProgress(newValue, animated: false)
		}
	}
	
	func setProgress(_ progress: Float, animated: Bool) {
		_progress = progress
		let frame = self.frame
		setupProgressBar(frame: frame)
		
		if animated {
			UIView.animate(withDuration: 1.0, delay: 0.0, options: [.curveEaseIn, .curveEaseOut], animations: {
				self.updateProgress(frame: frame)
            }, completion: nil)
		} else {
			updateProgress(frame: frame)
		}
	}
	
	// MARK: Private
	
	private var _progress: Float = 0.0
	private var currentSize: CGSize = CGSize()
	private let progressView = UIView.init()
	private let firstImageView = UIImageView.init(frame: CGRect())
	private let secondImageView = UIImageView.init(frame: CGRect())
	private var progressImage: UIImage? {
		didSet {
			// stop animations
			firstImageView.layer.removeAllAnimations()
			secondImageView.layer.removeAllAnimations()
			
			// adjust sizes and layout
			let imageSize = progressImage != nil ? progressImage?.size : CGSize()
			
			firstImageView.image = progressImage
			firstImageView.frame.size = imageSize!
			secondImageView.image = progressImage
			secondImageView.frame.size = imageSize!
			
			setNeedsLayout()
		}
	}
	
	// MARK: Layout
	
	override func layoutSubviews() {
		super.layoutSubviews()
		
		setupProgressBar(frame: frame)
		updateProgress(frame: frame)
	}
	
	private func setupProgressBar(frame: CGRect) {
		if frame.size != currentSize {
			currentSize = frame.size
			
			let atvMode = (frame.height / 2.5 >= 20.0)
			let numberOfColors = (atvMode ? 6 : 7)
			let componentWidth = (atvMode ? frame.height / 5.0 : frame.height)
			
			let barFunction = {(context: CGContext, startX: CGFloat, componentSize: CGSize) in
				if atvMode {
					RainbowProgressBar.atvBar(context: context, startX: startX, componentSize: componentSize)
				} else {
					RainbowProgressBar.rainbowBar(context: context, startX: startX, componentSize: componentSize)
				}
			}
			progressImage = RainbowProgressBar.progressBarImage(estimatedSize:frame.size, componentSize: CGSize(width: componentWidth, height: self.bounds.height), barColors: numberOfColors, barFunction: barFunction)
			
			progressView.bounds = CGRect(origin: CGPoint(), size: self.currentSize)
			let progressFrame = progressView.bounds
			let imageFrame = firstImageView.frame
			
			firstImageView.frame = CGRect(x: progressFrame.width - imageFrame.width, y: CGFloat(0.0), width: imageFrame.width, height: imageFrame.height)
			secondImageView.frame = CGRect(x: self.firstImageView.frame.minX - imageFrame.width, y: CGFloat(0.0), width: imageFrame.width, height: imageFrame.height)
			
			UIView.animate(withDuration: 5.0, delay: 0.0, options: [.curveLinear, .repeat], animations: {
				self.firstImageView.frame = CGRect(x: progressFrame.size.width, y: CGFloat(0.0), width: imageFrame.width, height: imageFrame.height)
				self.secondImageView.frame = CGRect(x: self.firstImageView.frame.minX - imageFrame.width, y: CGFloat(0.0), width: imageFrame.width, height: imageFrame.height)
            }, completion: nil)
		}
	}
	
	private func updateProgress(frame: CGRect) {
		let progressWidth = frame.width * CGFloat(progress)
		let progressFrame = CGRect(x: -(frame.size.width - progressWidth), y: 0.0, width: frame.width, height: frame.height)
		progressView.frame = progressFrame
	}
	
	// MARK: Progress Image Generation
	
	static func progressBarImage(estimatedSize: CGSize, componentSize: CGSize, barColors: Int, barFunction: (_ context: CGContext, _ startX: CGFloat, _ componentSize: CGSize) -> Void) -> UIImage? {
		let numberOfGroups: Int = Int(ceil(estimatedSize.width / (componentSize.width * CGFloat(barColors))))
		let imageSize = CGSize(width: componentSize.width * CGFloat(barColors) * CGFloat(numberOfGroups), height: componentSize.height)
		
		var image: UIImage?
		UIGraphicsBeginImageContext(imageSize)
		
		if let context = UIGraphicsGetCurrentContext() {
			
			UIColor.white.setFill()
			context.fill(CGRect(x: 0, y: 0, width: imageSize.width, height: imageSize.height))
			
			for index in 0...numberOfGroups-1 {
				let groupSize = componentSize.width * CGFloat(barColors)
				let startX = CGFloat(index) * groupSize
				
				barFunction(context, startX, componentSize)
				
			}
			image = UIGraphicsGetImageFromCurrentImageContext()
		}
		
		UIGraphicsEndImageContext()
		
		return image
	}
	
	// MARK: Drawing functions
	
	static func rainbowBar(context: CGContext, startX: CGFloat, componentSize: CGSize) -> Void {
		// Red, Orange, Yellow, Green, Blue, Indigo, Violet
		
		UIColor.red.setFill()
		context.fill(CGRect(x: startX + 0 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height))
		
		UIColor.orange.setFill()
		context.fill(CGRect(x: startX + 1 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height))
		
		UIColor.yellow.setFill()
		context.fill(CGRect(x: startX + 2 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height))
		
		UIColor.green.setFill()
		context.fill(CGRect(x: startX + 3 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height))
		
		UIColor.blue.setFill()
		context.fill(CGRect(x: startX + 4 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height))
		
		UIColor(colorLiteralRed: 0.365, green: 0.463, blue: 0.796, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 5 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height))
		
		UIColor(colorLiteralRed: 0.5, green: 0.0, blue: 1.0, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 6 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height))
		
	}
	
	static func atvBar(context: CGContext, startX: CGFloat, componentSize: CGSize) -> Void {
		let miniBarPercentage = componentSize.width / componentSize.height
		
		// major bar
		
		UIColor(colorLiteralRed: 0.325, green: 0.647, blue: 0.180, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 0 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height * CGFloat(1.0 - miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.984, green: 0.667, blue: 0.067, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 1 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height * CGFloat(1.0 - miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.929, green: 0.361, blue: 0.082, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 2 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height * CGFloat(1.0 - miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.867, green: 0.000, blue: 0.094, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 3 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height * CGFloat(1.0 - miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.482, green: 0.106, blue: 0.467, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 4 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height * CGFloat(1.0 - miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.090, green: 0.514, blue: 0.808, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 5 * componentSize.width, y: 0, width: componentSize.width, height: componentSize.height * CGFloat(1.0 - miniBarPercentage)))
		
		// minibar
		
		UIColor(colorLiteralRed: 0.098, green: 0.086, blue: 0.090, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 0 * componentSize.width, y: componentSize.height * CGFloat(1.0 - miniBarPercentage), width: componentSize.width, height: componentSize.height * CGFloat(miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.482, green: 0.106, blue: 0.467, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 1 * componentSize.width, y: componentSize.height * CGFloat(1.0 - miniBarPercentage), width: componentSize.width, height: componentSize.height * CGFloat(miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.098, green: 0.086, blue: 0.090, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 2 * componentSize.width, y: componentSize.height * CGFloat(1.0 - miniBarPercentage), width: componentSize.width, height: componentSize.height * CGFloat(miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.090, green: 0.514, blue: 0.808, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 3 * componentSize.width, y: componentSize.height * CGFloat(1.0 - miniBarPercentage), width: componentSize.width, height: componentSize.height * CGFloat(miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.098, green: 0.086, blue: 0.090, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 4 * componentSize.width, y: componentSize.height * CGFloat(1.0 - miniBarPercentage), width: componentSize.width, height: componentSize.height * CGFloat(miniBarPercentage)))
		
		UIColor(colorLiteralRed: 0.984, green: 0.667, blue: 0.067, alpha: 1.0).setFill()
		context.fill(CGRect(x: startX + 5 * componentSize.width, y: componentSize.height * CGFloat(1.0 - miniBarPercentage), width: componentSize.width, height: componentSize.height * CGFloat(miniBarPercentage)))
	}
}
