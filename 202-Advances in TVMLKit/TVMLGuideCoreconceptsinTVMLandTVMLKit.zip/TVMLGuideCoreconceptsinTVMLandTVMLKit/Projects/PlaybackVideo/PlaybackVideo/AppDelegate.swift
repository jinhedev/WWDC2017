/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
The application-specific delegate class.
*/


import UIKit
import TVMLKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, TVApplicationControllerDelegate {
	// MARK: Properties
	
	var window: UIWindow?
	
	var appController: TVApplicationController?
	
	static let tvBaseURL = "http://localhost:9001/"
	
	static let tvBootURL = "\(AppDelegate.tvBaseURL)/application.js"
	
	static let tvMainScript = "PlaybackVideo/index.js"
	
	// MARK: UIApplicationDelegate
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey : Any]? = nil) -> Bool {
		window = UIWindow(frame: UIScreen.main.bounds)
		
		/*
		Create the TVApplicationControllerContext for this application and set
		the properties that will be passed to the `App.onLaunch` function in
		JavaScript.
		*/
		let appControllerContext = TVApplicationControllerContext()
		
		if let javaScriptURL = URL(string: AppDelegate.tvBootURL) {
			appControllerContext.javaScriptApplicationURL = javaScriptURL
		}
		
		appControllerContext.launchOptions["baseURL"] = AppDelegate.tvBaseURL
		appControllerContext.launchOptions["mainScript"] = AppDelegate.tvMainScript

        for (key, value) in launchOptions ?? [:] {
            appControllerContext.launchOptions[key.rawValue] = value
        }
		
		// Create a `TVApplicationController` with the context and app window.
		appController = TVApplicationController(context: appControllerContext, window: window, delegate: self)
		
		return true
	}
	
	func appController(_ appController: TVApplicationController, didFail error: Error) {
		print("\(#function) invoked with error: \(error)")
		
		let title = "Error Launching Application"
		let message = error.localizedDescription
		let alertController = UIAlertController(title: title, message: message, preferredStyle:.alert )
		
		self.appController?.navigationController.present(alertController, animated: true, completion: nil)
	}
}
