/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
A JSExport protocol that defines a method to return a TVML document for a given name.
        This protocol is implemented by `DocumentVendor` and registered with the JavaScript context by `AppDelegate`.
*/

import TVMLKit

@objc
protocol DocumentVending : JSExport {
	func getDocument(name: String) -> String?
}
