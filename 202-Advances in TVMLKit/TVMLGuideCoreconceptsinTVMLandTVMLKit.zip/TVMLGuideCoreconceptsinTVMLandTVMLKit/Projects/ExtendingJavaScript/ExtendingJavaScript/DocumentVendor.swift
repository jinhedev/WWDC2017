/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
An NSObject subclass that implements the `DocumentVending` protocol.
*/

import TVMLKit

class DocumentVendor: NSObject, DocumentVending {
    // MARK: Properties
    
    private let resourceBundle: Bundle
    
    // MARK: Initialization
    
    init(resourceBundle: Bundle) {
        self.resourceBundle = resourceBundle
    }
    
    // MARK: DocumentVending
    
    func getDocument(name: String) -> String? {
        // Get the file path for the page resource.
        guard let filePath = resourceBundle.path(forResource: name, ofType: "xml") else {
            return nil
        }
        
        // Return the contents of the file as a string.
        do {
            return try String(contentsOfFile: filePath, encoding: .utf8)
        }
        catch {
            return nil
        }
    }
}
