# ExtendingJavaScript

This sample demonstrates how bridge native objects and classes into JavaScript to extend TVML.

## Requirements

### Build

Xcode 8.0, tvOS 10.0 SDK

### Runtime

tvOS 10.0 or later

## Structure

The project "Projects/ExtendingJavaScript" is split into two parts:

- ExtendingJavaScript: This directory contains the Xcode project and related files. The AppDelegate.swift file handles the setup of the TVMLKit framework and launching the JavaScript context to manage the app.

- Resources: This directory contains the main application.js JavaScript file and template XML files. The contents of this directory are copied into the application bundle and accessed locally.

Copyright (C) 2016 Apple Inc. All rights reserved.
