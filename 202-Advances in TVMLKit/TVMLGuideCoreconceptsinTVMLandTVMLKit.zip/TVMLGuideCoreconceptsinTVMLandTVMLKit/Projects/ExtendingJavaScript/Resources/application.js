/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
The main application JavaScript file.
*/

/**
 * The onLaunch callback is invoked after the application JavaScript has been
 * parsed into a JavaScript context.
 */
App.onLaunch = function(options) {
    // Load the start document using our convenience function.
    pushDocument("start");
};

/**
 * This functionality is implemented by the AppDelegate to demonstrate calling
 * into the JavaScript context. See Info.plist for custom URL scheme configuration.
 * The onOpenURL callback is invoked by the UIApplicationDelegate openURL callback.
 */
App.onOpenURL = function(url) {
    // Log the URL that was requested
    console.log("Handling openURL for URL:", url);

    // Extract the document name from the custom URL scheme
    const [protocol, path] = url.split("://");

    // Load the document by name using our convenience function
    pushDocument(path);
};

// Create a DOM Parser for creating documents from template strings
const parser = new DOMParser();

/*
 * Loads and pushes a document at a given URL onto the navigation stack.
 */
function pushDocument(name) {
    /**
     * Use the DocumentVendor object created by TVApplicationController's delegate
     * to load the XML for the requested document.
     */
    const documentXML = documentVendor.getDocumentWithName(name);
    if (documentXML) {
        // Parse the XML into a DOM document.
        const document = parser.parseFromString(documentXML, "application/xml");

        // Add an event listener to handle select events.
        document.addEventListener("select", handleSelectEvent);
        
        // Push the document onto the navigation stack.
        navigationDocument.pushDocument(document);
    }
}


/**
 * A function that is assigned to handle select events for elements to push new
 * documents.
 */
function handleSelectEvent(event) {
    // Check if the selected element has a `selectDocument` attribute set.
    const selectedElement = event.target;

    const selectDocument = selectedElement.getAttribute("selectDocument");
    if (selectDocument) {
        // Load the document by name using our convenience function.
        pushDocument(selectDocument);
    }

    const selectURL = selectedElement.getAttribute("selectURL");
    if (selectURL) {
        // Pass the URL to the system for dispatching.
        openURL(selectURL);
    }
}
