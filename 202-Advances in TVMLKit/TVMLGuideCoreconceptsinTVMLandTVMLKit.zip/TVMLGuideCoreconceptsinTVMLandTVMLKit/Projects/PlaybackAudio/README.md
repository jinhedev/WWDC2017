# PlaybackAudio

This sample demonstrates how to playback audio in your TVML application. It shows different the options available when playing back audio such as enabling background audio session and providing a context-sensitive tab bar button to interact with the Player.

## Requirements

### Build

Xcode 8.0, tvOS 10.0 SDK

### Runtime

tvOS 10.0 or later

## Structure

The project is split into two parts:

- Projects/PlaybackAudio: This directory contains the Xcode project and related files. The AppDelegate.swift file handles the setup of the TVMLKit framework and launching the JavaScript context to manage the app.

- Server/PlaybackAudio: This directory contains the main application.js JavaScript file and other resources. This directory must hosted on a web server that is accessible from the simulator or device.

## Local server instructions

If you would like use a simple, local web server to try this sample on the simulator, run the following command from the "Server" directory.

```
ruby -run -ehttpd . -p9001
```

This will start a single server instance that can be used when running any of the samples in the workspace. 

## Remote server instructions

If you are hosting the server files on a remote server, you will need to make the following changes to the application:

- Open the PlaybackAudio.xcodeproj project in Xcode
- Change the tvBaseURL property in AppDelegate.swift to match the URL hosting the contents of the Server directory.

## Security

Please note that the Info.plist file currently disables App Transport Security for the localhost domain. This is only to simplify the process of trying the sample. Your own apps should rely on properly secured servers that do not require App Transport Security to be disabled.

Copyright (C) 2016 Apple Inc. All rights reserved.
