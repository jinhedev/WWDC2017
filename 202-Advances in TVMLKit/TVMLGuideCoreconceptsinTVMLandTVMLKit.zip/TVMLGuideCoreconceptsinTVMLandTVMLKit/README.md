# TVML Guide: Core concepts in TVML and TVMLKit

A collection of sample code projects to teach TVMLKit.

## Overview

This sample is a collection of projects that each demonstrate a single concept for working with TVMLKit. These include media playback, extending templates, extending JavaScript and a music application.

## Projects

### Data Binding

This sample demonstrates how to use prototypes and data bindings in TVML templates.

### ExtendingTemplates

This sample demonstrates how to extend TVML templates by adding a custom view, view controller and a collection view cell.

### ExtendingJavaScript

This sample demonstrates how present TVML that has been loaded from the directly from the app. 

### PlaybackVideo

This sample demonstrates how to playback video in your TVML application. It shows various options that are available when playing back video such as highlight groups and playlists, as well as shows how to prevent users from skipping ads. New to tvOS 10.0, embedded video and interactive overlay are also demonstrated. 

### PlaybackAudio

This sample demonstrates music playback, now playing menu item feature and background application audio.

### Local server instructions

If you would like use a simple, local web server to try the samples on the simulator, run the following command from the "Server" directory.

```
ruby -run -ehttpd . -p9001
```

This will start a single server instance that can be used when running any of the samples in the workspace. 

### Remote server instructions

If you are hosting the server files on a remote server, you will need to make the following changes to the applications:

- Open each project in Xcode
- Change the [`tvBaseURL`](x-source-tag://tvBaseURL) property in AppDelegate.swift to match the URL hosting the contents of the Server directory.

## Security

Please note that the Info.plist files for each project currently disable App Transport Security for the localhost domain. This is only to simplify the process of trying the sample. Your own apps should rely on properly secured servers that do not require App Transport Security to be disabled.

## Requirements

### Build

Xcode 9.0, tvOS 11.0 SDK

### Runtime

tvOS 11.0 or later
