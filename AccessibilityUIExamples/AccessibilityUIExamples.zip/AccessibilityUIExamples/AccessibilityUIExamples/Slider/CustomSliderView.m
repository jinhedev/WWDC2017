/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Category for adoption on NSAccessibilitySlider.
*/

#import "AccessibilityUIExamples-Swift.h"

@interface CustomSliderView (Accessibility) <NSAccessibilitySlider>
@end

@implementation CustomSliderView (Accessibility)
@end
