/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View controller demonstrating an accessible custom NSView that behaves like a layout area with adjustable items.
*/

import Cocoa

class CustomLayoutAreaViewController: NSViewController {

}

