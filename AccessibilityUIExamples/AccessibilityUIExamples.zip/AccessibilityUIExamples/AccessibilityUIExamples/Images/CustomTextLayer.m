/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Category for adoption on NSAccessibilityStaticText.
*/

#import "AccessibilityUIExamples-Swift.h"

//@interface CustomTextLayer (Accessibility) <NSAccessibilityStaticText>
//@end
//
//@implementation CustomTextLayer (Accessibility)
//@end

