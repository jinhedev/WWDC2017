/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Category for adoption on NSAccessibilityImage.
*/

#import "AccessibilityUIExamples-Swift.h"

//@interface CustomImageLayer (Accessibility) <NSAccessibilityImage>
//@end
//
//@implementation CustomImageLayer (Accessibility)
//@end

