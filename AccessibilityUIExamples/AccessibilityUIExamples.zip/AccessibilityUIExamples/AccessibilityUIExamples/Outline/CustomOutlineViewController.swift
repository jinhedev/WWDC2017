/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View controller demonstrating an accessible, custom NSView subclass that behaves like an outline.
*/

import Cocoa

class CustomOutlineViewController: NSViewController {

}

