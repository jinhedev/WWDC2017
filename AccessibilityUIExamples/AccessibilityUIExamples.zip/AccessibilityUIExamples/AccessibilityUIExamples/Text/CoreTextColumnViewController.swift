/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View controller demonstrating an accessible, custom NSView subclass that draws columns of text using CoreText.
*/

import Cocoa

class CoreTextColumnViewController: NSViewController {

}

