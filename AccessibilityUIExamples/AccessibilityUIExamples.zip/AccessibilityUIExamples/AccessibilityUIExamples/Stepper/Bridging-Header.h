/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Use this file to import your target's public headers that you would like to expose to Swift.
*/

// Include header shared between this Metal shader code and Swift code executing Metal API commands.
#import "ShaderTypes.h"
