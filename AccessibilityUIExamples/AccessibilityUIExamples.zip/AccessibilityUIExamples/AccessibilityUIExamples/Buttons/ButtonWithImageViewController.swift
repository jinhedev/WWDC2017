/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View controller demonstrating accessibility provided by AppKit for an NSButton with an image.
*/

import Cocoa

class ButtonWithImageViewController: ButtonBaseViewController {

}

