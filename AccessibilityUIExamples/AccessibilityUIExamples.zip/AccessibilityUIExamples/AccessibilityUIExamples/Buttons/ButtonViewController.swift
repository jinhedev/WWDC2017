/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View controller demonstrating accessibility provided by AppKit for NSButton.
*/

import Cocoa

class ButtonViewController: ButtonBaseViewController {

}

