/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Constants for acessing button images.
*/

struct ButtonImages {
    static let buttonUp = "CustomButtonUp"
    static let buttonDown = "CustomButtonDown"
    static let buttonHighlight = "CustomButtonHighlight"
}
