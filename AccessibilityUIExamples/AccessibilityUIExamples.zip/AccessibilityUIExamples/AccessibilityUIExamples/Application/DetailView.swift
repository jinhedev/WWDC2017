/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Encompassing view that holds the detail view controller's content.
*/

import Cocoa

class DetailView: NSView {
    
}
