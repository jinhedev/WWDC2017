/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
This sample's application delegate.
*/

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

}
