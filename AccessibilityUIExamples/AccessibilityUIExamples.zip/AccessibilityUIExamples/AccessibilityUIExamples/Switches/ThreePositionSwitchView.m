/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Category for adoption on NSAccessibilitySwitch.
*/

#import "AccessibilityUIExamples-Swift.h"

@interface ThreePositionSwitchView (Accessibility) <NSAccessibilitySwitch>
@end

@implementation ThreePositionSwitchView (Accessibility)
@end
