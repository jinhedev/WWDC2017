/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View controller demonstrating an accessible, custom NSView subclass that behaves like a table.
*/

import Cocoa

class CustomTableViewController: NSViewController {

}

