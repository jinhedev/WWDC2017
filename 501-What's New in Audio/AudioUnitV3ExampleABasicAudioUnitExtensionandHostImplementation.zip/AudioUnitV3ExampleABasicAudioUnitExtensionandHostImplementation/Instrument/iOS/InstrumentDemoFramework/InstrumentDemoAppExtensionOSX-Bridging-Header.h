/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Bridging header for macOS InstrumentDemoAppExtension.
*/
#import "InstrumentDemoOSXViewController.h"
