/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Main entry point into the application
*/

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
