/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of renderer class which perfoms Metal setup and per frame rendering
*/

@import simd;
@import MetalKit;

#import "AAPLRenderer.h"
#import "AAPLImage.h"

// Header shared between C code here, which executes Metal API commands, and .metal files, which
//   uses these types as inpute to the shaders
#import "AAPLShaderTypes.h"


// Main class performing the rendering
@implementation AAPLRenderer
{
    // The device (aka GPU) we're using to render
    id <MTLDevice> _device;

    // The command Queue from which we'll obtain command buffers
    id<MTLCommandQueue> _commandQueue;

    // The Metal texture objects to be referenced via an indirect argument buffer
    id<MTLTexture> _textureA;
    id<MTLTexture> _textureB;
    id<MTLTexture> _textureC;
    id<MTLSamplerState> _sampler;

    // The Metal buffer in which we store our vertex data
    id<MTLBuffer> _vertices;

    // The number of vertices in our vertex buffer
    NSUInteger _numVertices;

    // The current size of our view so we can use this in our render pipeline
    vector_uint2 _viewportSize;

    // Our render pipeline composed of our vertex and fragment shaders in the .metal shader file
    id<MTLRenderPipelineState> _texturePipelineState;
    id<MTLRenderPipelineState> _colorRectPipelineState;

    id<MTLBuffer> _vertexShaderArgumentBuffer;
    id<MTLBuffer> _textureShaderArgumentBuffer;
    id<MTLBuffer> _colorRectShaderArgumentBuffer;

    id<MTLBuffer> _redRects;
    id<MTLBuffer> _greenRects;
    id<MTLBuffer> _blueRects;

    NSUInteger _offsetArgumentLength;

}

/// Initialize with the MetalKit view from which we'll obtain our metal device
- (nonnull instancetype)initWithMetalKitView:(nonnull MTKView *)mtkView
{
    self = [super init];
    if(self)
    {
        _device = mtkView.device;

        mtkView.clearColor = MTLClearColorMake(0.0, 0.5, 0.5, 1.0f);

        MTKTextureLoader *textureLoader = [[MTKTextureLoader alloc] initWithDevice:_device];

        NSError *error;

        _textureA = [textureLoader newTextureWithName:@"TextureA" scaleFactor:1.0 bundle:nil options:nil error:&error];

        if(!_textureA)
        {
            NSLog(@"Could not load TextureA: %@", error.localizedDescription);
            return nil;
        }

        _textureB = [textureLoader newTextureWithName:@"TextureB" scaleFactor:1.0 bundle:nil options:nil error:&error];

        if(!_textureB)
        {
            NSLog(@"Could not load TextureB: %@", error.localizedDescription);
            return nil;
        }

        _textureC = [textureLoader newTextureWithName:@"TextureC" scaleFactor:1.0 bundle:nil options:nil error:&error];

        if(!_textureC)
        {
            NSLog(@"Could not load TextureC: %@", error.localizedDescription);
            return nil;
        }

        MTLSamplerDescriptor *samplerDesc = [MTLSamplerDescriptor new];
        samplerDesc.minFilter = MTLSamplerMinMagFilterLinear;
        samplerDesc.magFilter = MTLSamplerMinMagFilterLinear;
        samplerDesc.mipFilter = MTLSamplerMinMagFilterLinear;

        _sampler = [_device newSamplerStateWithDescriptor:samplerDesc];

        // Set up a simple MTLBuffer with our vertices which include texture coordinates
        static const AAPLVertex quadVertices[] =
        {
            //Pixel Positions, Texture Coordinates
            { {  250,  -250 }, { 1.f, 0.f } },
            { { -250,  -250 }, { 0.f, 0.f } },
            { { -250,   250 }, { 0.f, 1.f } },

            { {  250,  -250 }, { 1.f, 0.f } },
            { { -250,   250 }, { 0.f, 1.f } },
            { {  250,   250 }, { 1.f, 1.f } },
        };

        // Create our vertex buffer, and intializat it with our quadVertices array
        _vertices = [_device newBufferWithBytes:quadVertices
                                         length:sizeof(quadVertices)
                                        options:MTLResourceStorageModeShared];


        // Calculate the number of vertices by dividing the byte length by the size of each vertex
        _numVertices = sizeof(quadVertices) / sizeof(AAPLVertex);


        static const AAPLRect redRects[] =
        {
            { .25f, 0.1f, 0.3f, 0.1f},
            { .75f, 0.4f, 0.2f, 0.5f},
            { 0.0f, 0.7f, 0.2f, 0.2f},
        };

        _redRects = [_device newBufferWithBytes:redRects
                                         length:sizeof(redRects)
                                        options:MTLResourceStorageModeShared];

        uint32_t numRedRects = sizeof(redRects) / sizeof(AAPLRect);


        static const AAPLRect greenRects[] =
        {
            { 0.1f, 0.4f, .25f, .25f },
            { 0.6f, 0.1f, .35f, 0.3f },
            { 0.3f, 0.7f, 0.5f, 0.2f },
            { .55f, .45f, .35f, 0.2f },
        };

        _greenRects = [_device newBufferWithBytes:greenRects
                                           length:sizeof(greenRects)
                                          options:MTLResourceStorageModeShared];

        uint32_t numGreenRects = sizeof(greenRects) / sizeof(AAPLRect);

        static const AAPLRect blueRects[] =
        {
            { .05f, .05f, .3f, .3f },
            { .35f, .35f, .2f, .4f },
        };

        _blueRects = [_device newBufferWithBytes:blueRects
                                          length:sizeof(blueRects)
                                         options:MTLResourceStorageModeShared];

        uint32_t numBlueRects = sizeof(blueRects) / sizeof(AAPLRect);

        /// Create our render pipeline

        // Load all the shader files with a metal file extension in the project
        id<MTLLibrary> defaultLibrary = [_device newDefaultLibrary];

        // Load the vertex function from the library
        id <MTLFunction> vertexFunction = [defaultLibrary newFunctionWithName:@"vertexShader"];

        // Load the textureShader fragment function from the library
        id <MTLFunction> textureFunction = [defaultLibrary newFunctionWithName:@"textureShader"];

        // Set up a descriptor for creating a pipeline state object
        MTLRenderPipelineDescriptor *pipelineStateDescriptor = [[MTLRenderPipelineDescriptor alloc] init];
        pipelineStateDescriptor.label = @"Texturing Pipeline";
        pipelineStateDescriptor.vertexFunction = vertexFunction;
        pipelineStateDescriptor.fragmentFunction = textureFunction;
        pipelineStateDescriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat;
        _texturePipelineState = [_device newRenderPipelineStateWithDescriptor:pipelineStateDescriptor
                                                                        error:&error];
        if (!_texturePipelineState)
        {
            NSLog(@"Failed to create texture pipeline state, error %@", error.localizedDescription);
        }

        // Load the colorRectShader fragment function from the library
        id <MTLFunction> colorRectFunction = [defaultLibrary newFunctionWithName:@"colorRectShader"];

        pipelineStateDescriptor.label = @"ColorRect Pipeline";
        pipelineStateDescriptor.vertexFunction = vertexFunction;
        pipelineStateDescriptor.fragmentFunction = colorRectFunction;
        _colorRectPipelineState = [_device newRenderPipelineStateWithDescriptor:pipelineStateDescriptor
                                                                        error:&error];
        if (!_colorRectPipelineState)
        {
            NSLog(@"Failed to create color rect pipeline state, error %@", error.localizedDescription);
        }

        id <MTLIndirectArgumentEncoder> argumentEncoder = nil;

        // Encode arguments for 'textureShader'
        ////////////////////////////////////////
        argumentEncoder = [textureFunction newIndirectArgumentEncoderWithBufferIndex:AAPLFragmentBufferIndexArguments];

        _textureShaderArgumentBuffer = [_device newBufferWithLength:argumentEncoder.encodedLength options:0];

        [argumentEncoder setIndirectArgumentBuffer:_textureShaderArgumentBuffer offset:0];

        [argumentEncoder setTexture:_textureA atIndex:AAPLArgumentBufferIndexTextureA];

        [argumentEncoder setTexture:_textureB atIndex:AAPLArgumentBufferIndexTextureB];

        [argumentEncoder setTexture:_textureC atIndex:AAPLArgumentBufferIndexTextureC];

        [argumentEncoder setSamplerState:_sampler atIndex:AAPLArgumentBufferIndexSampler];

        // Encode arguments for 'colorRectShader'
        /////////////////////////////////////////
        argumentEncoder = [colorRectFunction newIndirectArgumentEncoderWithBufferIndex:AAPLFragmentBufferIndexArguments];

        _colorRectShaderArgumentBuffer = [_device newBufferWithLength:argumentEncoder.encodedLength options:0];

        [argumentEncoder setIndirectArgumentBuffer:_colorRectShaderArgumentBuffer offset:0];

        [argumentEncoder setBuffer:_redRects offset:0 atIndex:AAPLArgumentBufferIndexRedRects];

        [argumentEncoder setBuffer:_greenRects offset:0 atIndex:AAPLArgumentBufferIndexGreenRects];

        [argumentEncoder setBuffer:_blueRects offset:0 atIndex:AAPLArgumentBufferIndexBlueRects];

        uint32_t *numRedRectsArg = (uint32_t *)[argumentEncoder constantDataAtIndex:AAPLArgumentBufferIndexNumRedRects];

        *numRedRectsArg = numRedRects;

        uint32_t *numGreenRectsArg = (uint32_t *)[argumentEncoder constantDataAtIndex:AAPLArgumentBufferIndexNumGreenRects];

        *numGreenRectsArg = numGreenRects;

        uint32_t *numBlueRectsArg = (uint32_t *)[argumentEncoder constantDataAtIndex:AAPLArgumentBufferIndexNumBlueRects];

        *numBlueRectsArg = numBlueRects;

        // Encode arguments for 'vertexShader'
        /////////////////////////////////////////
        argumentEncoder = [vertexFunction newIndirectArgumentEncoderWithBufferIndex:AAPLVertexBufferIndexArguments];

        // Save the argument buffer size since we'll store 2 elements in it and we'll need this
        //   to offset into the second element when we set the buffer.
        _offsetArgumentLength = argumentEncoder.encodedLength;

        NSUInteger argumentBufferLength = _offsetArgumentLength * 2;

        _vertexShaderArgumentBuffer = [_device newBufferWithLength:argumentBufferLength options:0];

        [argumentEncoder setIndirectArgumentBuffer:_vertexShaderArgumentBuffer offset:0];

        uint8_t * argumentData = (uint8_t*)[argumentEncoder constantDataAtIndex:AAPLArgumentBufferIndexPositionOffset];

        vector_float2* offset = (vector_float2*)argumentData;

        offset->x = 250;
        offset->y = 250;

        offset = (vector_float2*)(argumentData+_offsetArgumentLength);

        offset->x = -250;
        offset->y = -250;

        // Create the command queue
        _commandQueue = [_device newCommandQueue];
    }

    return self;
}

/// Called whenever view changes orientation or is resized
- (void)mtkView:(nonnull MTKView *)view drawableSizeWillChange:(CGSize)size
{
    // Save the size of the drawable as we'll pass these
    //   values to our vertex shader when we draw
    _viewportSize.x = size.width;
    _viewportSize.y = size.height;
}

/// Called whenever the view needs to render a frame
- (void)drawInMTKView:(nonnull MTKView *)view
{

    // Create a new command buffer for each renderpass to the current drawable
    id <MTLCommandBuffer> commandBuffer = [_commandQueue commandBuffer];
    commandBuffer.label = @"MyCommand";

    // Obtain a renderPassDescriptor generated from the view's drawable textures
    MTLRenderPassDescriptor *renderPassDescriptor = view.currentRenderPassDescriptor;

    if(renderPassDescriptor != nil)
    {
        // Create a render command encoder so we can render into something
        id <MTLRenderCommandEncoder> renderEncoder =
        [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        renderEncoder.label = @"MyRenderEncoder";

        [renderEncoder setVertexBuffer:_vertices
                                offset:0
                               atIndex:AAPLVertexBufferIndexVertices];

        [renderEncoder setVertexBytes:&_viewportSize
                               length:sizeof(_viewportSize)
                              atIndex:AAPLVertexBufferIndexViewportSize];

        // Setup state and render with the texture shader
        /////////////////////////////////////////////////

        [renderEncoder setRenderPipelineState:_texturePipelineState];

        [renderEncoder useResource:_textureA usage:MTLResourceUsageSample];
        [renderEncoder useResource:_textureB usage:MTLResourceUsageSample];
        [renderEncoder useResource:_textureC usage:MTLResourceUsageSample];

        [renderEncoder setVertexBuffer:_vertexShaderArgumentBuffer
                                offset:0
                               atIndex:AAPLVertexBufferIndexArguments];

        [renderEncoder setFragmentBuffer:_textureShaderArgumentBuffer
                                  offset:0
                                 atIndex:AAPLFragmentBufferIndexArguments];

        [renderEncoder drawPrimitives:MTLPrimitiveTypeTriangle
                          vertexStart:0
                          vertexCount:_numVertices];

        // Setup state and render with the colorRect shader
        ///////////////////////////////////////////////////

        [renderEncoder setRenderPipelineState:_colorRectPipelineState];

        [renderEncoder useResource:_redRects   usage:MTLResourceUsageRead];
        [renderEncoder useResource:_greenRects usage:MTLResourceUsageRead];
        [renderEncoder useResource:_blueRects  usage:MTLResourceUsageRead];

        [renderEncoder setVertexBuffer:_vertexShaderArgumentBuffer
                                offset:_offsetArgumentLength
                               atIndex:AAPLVertexBufferIndexArguments];

        [renderEncoder setFragmentBuffer:_colorRectShaderArgumentBuffer
                                  offset:0
                                 atIndex:AAPLFragmentBufferIndexArguments];

        [renderEncoder drawPrimitives:MTLPrimitiveTypeTriangle
                          vertexStart:0
                          vertexCount:_numVertices];

        [renderEncoder endEncoding];

        // Schedule a present once the framebuffer is complete using the current drawable
        [commandBuffer presentDrawable:view.currentDrawable];
    }

    
    // Finalize rendering here & push the command buffer to the GPU
    [commandBuffer commit];
}

@end

