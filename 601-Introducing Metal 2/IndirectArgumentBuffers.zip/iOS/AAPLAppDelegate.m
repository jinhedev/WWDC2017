/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of our iOS Application Delegate
*/


#import "AAPLAppDelegate.h"

@interface AAPLAppDelegate ()

@end

@implementation AAPLAppDelegate

@end
