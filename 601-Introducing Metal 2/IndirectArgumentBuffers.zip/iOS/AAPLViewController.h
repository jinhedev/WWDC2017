/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for our iOS view controller
*/

@import UIKit;
@import MetalKit;

#import "AAPLRenderer.h"

// Our iOS specific view controller
@interface AAPLViewController : UIViewController

@end
