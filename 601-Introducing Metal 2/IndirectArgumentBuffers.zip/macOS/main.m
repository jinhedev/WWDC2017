/*
See LICENSE folder for this sample’s licensing information.

Abstract:
macOS Application Entrypoint
*/

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
