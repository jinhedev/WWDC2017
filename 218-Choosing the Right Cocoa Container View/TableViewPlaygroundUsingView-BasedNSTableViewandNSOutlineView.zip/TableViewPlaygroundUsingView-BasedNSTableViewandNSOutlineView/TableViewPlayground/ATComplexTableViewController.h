/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The basic controller for the demo app. An instance exists inside the MainMenu.xib file.
 */

@import Cocoa;

@interface ATComplexTableViewController : NSWindowController

@end
