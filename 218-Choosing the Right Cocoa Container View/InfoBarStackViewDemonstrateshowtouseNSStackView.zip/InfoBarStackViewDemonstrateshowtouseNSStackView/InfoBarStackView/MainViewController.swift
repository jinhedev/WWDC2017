/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 This sample's primary view controller.
 */

import Cocoa

class MainViewController : NSViewController {
    
    /// User wants to show the stack view window.
    @IBAction func showStackView(_ sender: AnyObject) {
        
        let appDelegate = NSApplication.shared().delegate as! AppDelegate
        appDelegate.stackViewWindowController.showWindow(self)
    }

}
