/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Stack item view controller for displaying a simple NSCollectionView of images.
 */

import Cocoa

class CollectionViewController : BaseViewController, NSCollectionViewDataSource, NSCollectionViewDelegate {
    
    @IBOutlet weak var collection: NSCollectionView!

    private static let collectionItemIdentifier = "CollectionItem"
    
    override func headerTitle() -> String { return NSLocalizedString("Images Header Title", comment: "") }
    
    var savedCollectionViewSelection: IndexSet = IndexSet() {
        didSet {
            collection.selectionIndexes = savedCollectionViewSelection as IndexSet
            
            // Invalidate state restoration, which will in turn eventually call "encodeRestorableState".
            invalidateRestorableState()
        }
    }
    
    // MARK: - View Controller Lifecycle
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        collection.wantsLayer = true
        collection.layer?.backgroundColor = BaseViewController.StackItemBackgroundColor.cgColor
        
        // Compute the default height of this view so later we can hide/show it later.
        let size = collection.collectionViewLayout?.collectionViewContentSize
        savedDefaultHeight = size!.height
        
        // Must register the cell we're going to use for display in the collection.
        collection.register(CollectionItem.self, forItemWithIdentifier: CollectionViewController.collectionItemIdentifier)
        
        collection.enclosingScrollView?.borderType = .noBorder
        
        collection.reloadData()
    }
    
    // MARK: - NSCollectionViewDataSource
    
    func collectionView(_ collectionView: NSCollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func numberOfSections(in collectionView: NSCollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: NSCollectionView, itemForRepresentedObjectAt indexPath: IndexPath) -> NSCollectionViewItem {
        
        // Determine the image to be assigned to this collection view item.
        let cell = collectionView.makeItem(withIdentifier: CollectionViewController.collectionItemIdentifier, for: indexPath) as! CollectionItem
        var name: String
        switch ((indexPath as NSIndexPath).item) {
        case 0:
            name = "scene1"
        case 1:
            name = "scene2"
        case 2:
            name = "scene3"
        default:
            name = ""
        }
        cell.imageView?.image = NSImage(named: name)
        
        return cell
    }
    
    // MARK: - NSCollectionViewDelegate
    
    func collectionView(_ collectionView: NSCollectionView, didSelectItemsAt indexPaths: Set<IndexPath>) {
        
        print("collectionView: didSelectItemsAt: \(indexPaths)")
        
        // Invalidate state restoration, which will in turn eventually call "encodeRestorableState".
        invalidateRestorableState()
    }
    
}

// MARK: - State Restoration

extension CollectionViewController {
    
    // Restorable key for the collection view selection.
    private static let collectionViewSelectionKey = "collectionViewSelectionKey"
    
    /// Encode state. Helps save the restorable state of this view controller.
    override func encodeRestorableState(with coder: NSCoder) {
        
        coder.encode(collection.selectionIndexes, forKey: CollectionViewController.collectionViewSelectionKey)
        super.encodeRestorableState(with: coder)
    }
    
    /// Decode state. Helps restore any previously stored state.
    override func restoreState(with coder: NSCoder) {
        
        super.restoreState(with: coder)
        savedCollectionViewSelection = coder.decodeObject(forKey: CollectionViewController.collectionViewSelectionKey) as! IndexSet
    }
    
}
