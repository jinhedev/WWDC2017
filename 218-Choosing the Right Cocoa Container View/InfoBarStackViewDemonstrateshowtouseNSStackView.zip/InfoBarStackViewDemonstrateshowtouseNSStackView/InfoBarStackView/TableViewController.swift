/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Stack item view controller for displaying a simple NSTableView.
 */

import Cocoa

class TableViewController : BaseViewController, NSTableViewDelegate {
    
    private struct TableItemKeys {
        static let kFirstNameKey = "firstname"
        static let kLastNameKey = "lastname"
        static let kPhoneKey = "phone"
    }

    @IBOutlet weak var tableView: NSTableView!
    @IBOutlet var myContentArray: NSArrayController!
        
    override func headerTitle() -> String { return NSLocalizedString("Table Header Title", comment: "") }
    
    var savedTableSelection: Int = -1 {
        didSet {
            _ = myContentArray.setSelectionIndex(savedTableSelection)
            
            // Invalidate state restoration, which will in turn eventually call "encodeRestorableState".
            invalidateRestorableState()
        }
    }
    
    // MARK: - View Controller Lifecycle
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        tableView.enclosingScrollView?.borderType = .noBorder
        
        // Add the peoeple to the table view.
        let person1: [String : String] = [
            TableItemKeys.kFirstNameKey: "Joe",
            TableItemKeys.kLastNameKey: "Smith",
            TableItemKeys.kPhoneKey: "(444) 444-4444"
        ]
        myContentArray.addObject(person1)
        
        let person2: [String : String] = [
            TableItemKeys.kFirstNameKey: "Sally",
            TableItemKeys.kLastNameKey: "Allen",
            TableItemKeys.kPhoneKey: "(555) 555-5555"
        ]
        myContentArray.addObject(person2)
        
        let person3: [String : String] = [
            TableItemKeys.kFirstNameKey: "Mary",
            TableItemKeys.kLastNameKey: "Miller",
            TableItemKeys.kPhoneKey: "(777) 777-7777"
        ]
        myContentArray.addObject(person3)
        
        let person4: [String : String] = [
            TableItemKeys.kFirstNameKey: "John",
            TableItemKeys.kLastNameKey: "Zitmayer",
            TableItemKeys.kPhoneKey: "(888) 888-8888"
        ]
        myContentArray.addObject(person4)

        // Adjust the tableView's scroll view frame height constraint to match the content in our table.
        let headerView = tableView.headerView
        let headerRect = headerView?.headerRect(ofColumn: 0)
        let people = myContentArray.arrangedObjects as! Array<AnyObject>
        let preferredSize = people.count * (Int(tableView.rowHeight) + 2) + Int((headerRect?.size.height)!)
        
        heightConstraint?.constant = CGFloat(preferredSize)
        savedDefaultHeight = CGFloat(preferredSize)
    }
    
    // MARK: - NSTableViewDelegate

    func tableView(_ tableView: NSTableView, didAdd rowView: NSTableRowView, forRow row: Int) {
        
        // Each row background draws in a light gray color.
        rowView.backgroundColor = BaseViewController.StackItemBackgroundColor
    }

    func tableViewSelectionDidChange(_ notification: Notification) {
    
        if tableView.selectedRow < 0 {
            print("table: row de-selected")
        }
        else {
            // Report the selected person in the table.
            let selectedPerson = myContentArray.selectedObjects.first as! [String : String]
            let name = selectedPerson[TableItemKeys.kFirstNameKey]! + " " + selectedPerson[TableItemKeys.kLastNameKey]!
            print("table: row \(tableView.selectedRow) was selected: \(name as String)")
        }
        
        // Invalidate state restoration, which will in turn eventually call "encodeRestorableState".
        invalidateRestorableState()
    }

}

// MARK: - State Restoration

extension TableViewController {
    
    // Restorable key for the table selection.
    private static let tableSelectionKey = "tableSelectionKey"
    
    /// Encode state. Helps save the restorable state of this view controller.
    override func encodeRestorableState(with coder: NSCoder) {
        
        coder.encode(myContentArray.selectionIndex, forKey: TableViewController.tableSelectionKey)
        super.encodeRestorableState(with: coder)
    }
    
    /// Decode state. Helps restore any previously stored state.
    override func restoreState(with coder: NSCoder) {
        
        super.restoreState(with: coder)
        savedTableSelection = coder.decodeInteger(forKey: TableViewController.tableSelectionKey)
    }
    
}
