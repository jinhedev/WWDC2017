/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application delegate
*/

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

}

