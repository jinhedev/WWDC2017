/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for MacOS app framework
*/

#import <Cocoa/Cocoa.h>

//! Project version number for PicturesFrameworkMacOS.
FOUNDATION_EXPORT double PicturesFrameworkMacOSVersionNumber;

//! Project version string for PicturesFrameworkMacOS.
FOUNDATION_EXPORT const unsigned char PicturesFrameworkMacOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PicturesFrameworkMacOS/PublicHeader.h>


