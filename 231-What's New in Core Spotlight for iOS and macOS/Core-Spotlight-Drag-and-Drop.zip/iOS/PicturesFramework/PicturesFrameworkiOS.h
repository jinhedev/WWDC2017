/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for PicturesFrameworkiOS
*/

#import <UIKit/UIKit.h>

//! Project version number for PicturesFrameworkiOS.
FOUNDATION_EXPORT double PicturesFrameworkiOSVersionNumber;

//! Project version string for PicturesFrameworkiOS.
FOUNDATION_EXPORT const unsigned char PicturesFrameworkiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PicturesFrameworkiOS/PublicHeader.h>


