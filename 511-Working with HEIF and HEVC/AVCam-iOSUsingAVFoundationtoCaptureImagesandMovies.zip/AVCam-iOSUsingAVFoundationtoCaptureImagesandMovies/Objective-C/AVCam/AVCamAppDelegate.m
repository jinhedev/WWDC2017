/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Application delegate.
*/

#import "AVCamAppDelegate.h"

@implementation AVCamAppDelegate

@end
